# SE-Natural-Bloom-Dirty-Lens

A post-processing effect for Unity which adds energy-conserving bloom and dirty lens effects.

# Installation

Simply copy the "Assets/SE Natural Bloom" folder into your Unity project's Assets folder. Then, check the User Guide.pdf for usage instructions.