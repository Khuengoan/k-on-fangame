using UnityEngine;
using System.Collections;

public static class SENBDLGlobal
{
	public static Quaternion sphereOfCubesRotation;
	public static SENBDLMainCube mainCube;
	public static float timeScale;
}
